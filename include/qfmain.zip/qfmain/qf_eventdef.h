#ifndef qf_eventdef_h__
#define qf_eventdef_h__

#define QF_MESSAGE_MAIN_DELETE  "QF_MESSAGE_MAIN_DELETE"


#endif // qf_eventdef_h__
