/********************************************************************
	filename: 	qf_interfacedef.h
	author:		Ling Song
	date: 		���� 2017
*********************************************************************/
#ifndef qf_interfacedef_h__
#define qf_interfacedef_h__

#define QF_INTERFACE_MAIN_COMMAND "QF_INTERFACE_MAIN_COMMAND"

#define QF_INTERFACE_MAIN_MESSAGE "QF_INTERFACE_MAIN_MESSAGE"

#endif // qf_interfacedef_h__
